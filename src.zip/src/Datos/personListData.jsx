export const personListData = [
    {nota1: 10, name:'Laura', nota2: 8 }
   ];